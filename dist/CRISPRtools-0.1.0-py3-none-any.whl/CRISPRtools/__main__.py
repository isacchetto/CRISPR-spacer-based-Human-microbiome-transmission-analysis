import sys

if __name__ == "__main__":
    from twisted.application.twist._twist import Twist

    sys.exit(Twist.main())